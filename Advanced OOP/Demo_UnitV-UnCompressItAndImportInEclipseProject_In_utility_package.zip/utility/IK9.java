package utility;

public interface IK9 extends IDog {
	void waitHere();
}
